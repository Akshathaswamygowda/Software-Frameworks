﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CECS475Assignment5
{
    class MMABooksEntity
    {
        public static MMABooksEntities mmaBooks = new MMABooksEntities();
    }
}
