﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolDBAssignment6
{
    class SchoolDatabaseEntity
    {
        public static SchoolDBEntities schoolEntity = new SchoolDBEntities();
    }
}
